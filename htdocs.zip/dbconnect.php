<?php
    $host = '127.0.0.1';
    $user = 'root';
    $pass = 'tmxkfoq123';
    $dbname = 'htb';
    ?>