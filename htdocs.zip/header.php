<!DOCTYPE html>
<html>

<head>
    <title>How to breed?</title>
    <meta charset="utf-8">
    <!-- css 분리 -->
    <link rel="stylesheet" type="text/css" href="main.css?ver=0.00"/>

    <!-- CDN방식 jQuery 사용 선언 -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

    <!-- jQuery 분리. jQuery파일은 javascript 파일로 저장. -->
    <script src="scripts/post.js?ver=0.0011"></script>

    <meta charset="utf-8" />
        <link rel="stylesheet" href="main.css">
</head>

<body>
    <header>
        
    </header>